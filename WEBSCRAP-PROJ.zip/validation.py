import os
import pandas as pd
import re

# Folder path containing Excel files
folder_path = r"C:\Users\ROSHAN DAVID\OneDrive\Desktop\vahan-details"

# List of Excel files in the folder
excel_files = [file for file in os.listdir(folder_path) if file.endswith(".xlsx")]

# Define regex patterns for extraction
state_pattern = r', (.*?) \('
branch_pattern = r'of (.*?) - |of (.*?) \('
regno_pattern = r'- (\w+) ,'
year_pattern = r'\((\d{4}-\d{4})\)'

# Initialize an empty DataFrame to store the extracted data
data_df = pd.DataFrame()

# Process each Excel file
for excel_file in excel_files:
    excel_file_path = os.path.join(folder_path, excel_file)

    # Read the first row (A1) from the Excel file
    df = pd.read_excel(excel_file_path, nrows=1, header=None)
    input_string = df.iat[0, 0]

    # Process the input_string using the regex patterns
    state_match = re.search(state_pattern, input_string)
    branch_match = re.search(branch_pattern, input_string)
    regno_match = re.search(regno_pattern, input_string)
    year_match = re.search(year_pattern, input_string)

    if state_match:
        state = state_match.group(1).strip()
    else:
        state_alt_pattern = r'of (.*?) \('
        state_alt_match = re.search(state_alt_pattern, input_string)
        if state_alt_match:
            state = state_alt_match.group(1).strip()
        else:
            state = "N/A"

    if branch_match and branch_match.group(1):
        branch = branch_match.group(1).strip()
    else:
        branch = "N/A"

    regno = regno_match.group(1).strip() if regno_match else "N/A"
    year = year_match.group(1).strip() if year_match else "N/A"

    # Change Branch and Regno to "ALL" if both are N/A
    if branch == "N/A" and regno == "N/A":
        branch = "ALL"
        regno = "ALL"

    # Read the Excel file into a DataFrame, starting from row A6
    df_data = pd.read_excel(excel_file_path, skiprows=5)

    # Add extracted values as new columns
    df_data["State"] = state
    df_data["Branch"] = branch
    df_data["Regno"] = regno
    df_data["Year"] = year

    # Concatenate the current DataFrame with the main DataFrame
    data_df = pd.concat([data_df, df_data], ignore_index=True)

    formatted_info = f"State-{state}, Branch-{branch}, Regno-{regno}, Year-{year}"

    print(f"File: {excel_file}")
    print(formatted_info)
    print("=" * 50)

# Now you have the consolidated DataFrame 'data_df' containing the extracted data
# and you can perform further analysis or processing as needed.
