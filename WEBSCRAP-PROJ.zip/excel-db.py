import os
import pandas as pd
from datetime import datetime
from sqlalchemy import create_engine

# Folder containing your Excel files
folder_path = r"C:\Users\ROSHAN DAVID\OneDrive\Desktop\vahan-details\updated_excel"

# List to store individual DataFrames
dfs = []

# Loop through each file in the folder
for filename in os.listdir(folder_path):
    if filename.endswith('.xlsx'):
        file_path = os.path.join(folder_path, filename)
        # Read the Excel file skipping the first 4 rows (0-indexed)
        df = pd.read_excel(file_path, skiprows=4, header=None)
        dfs.append(df)
        print(df)

# Concatenate all DataFrames into a single DataFrame
combined_df = pd.concat(dfs, ignore_index=True)

# Define the new column headers for the combined DataFrame
new_headers = [
    "F-S No", "Maker", "2WIC", "2WN", "2WT", "3WN", "3WT", "4WIC",
    "HGV", "HMV", "HPV", "LGV", "LMV", "LPV", "MGV", "MMV", "MPV",
    "OTH", "TOTAL", "Downloaded Time", "STATE", "BRANCH", "REG-NO", "YEAR"
]

# Set the new column headers for the combined DataFrame
combined_df.columns = new_headers

# Add the 'DATA_INSERTED_TIME' column with the current timestamp in bold and uppercase
combined_df['DATA_INSERTED_TIME'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S").upper()

# Create a SQLAlchemy engine to connect to the PostgreSQL database
db_url = "postgresql://postgres:RDCR7@localhost/suppliers"  # Update with your connection details
engine = create_engine(db_url)

# Capture the start time
start_time = datetime.now()

# Insert the data from the DataFrame into the PostgreSQL table
combined_df.to_sql("vehicle_data", engine, if_exists="replace", index=False)

# Calculate the time taken for insertion
end_time = datetime.now()
time_taken = end_time - start_time

# Print a message indicating data insertion and time taken
print(f"Data has been inserted. Time taken: {time_taken}")

# Close the SQLAlchemy engine
engine.dispose()

# Print the final DataFrame
print(combined_df)

print("------------ ")

print("DATA HAS BEEN INSERTED SUCCESSFULLY")
