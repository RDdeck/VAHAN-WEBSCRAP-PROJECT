import subprocess
import schedule
import time
import os
import smtplib
from email.mime.text import MIMEText

MAX_RETRIES = 3  # Maximum number of retries
NEXT_SCHEDULE = 0.5  # Next schedule in minutes

def send_email_with_attachment(subject, message, recipient_emails, attachment_link):
    sender_email = "davidrockecr7@gmail.com"  # Replace with your sender email
    sender_password = "bplrjzncurivkddk"  # Replace with your generated app password

    # Create the email message
    email_body = f"{message}\n\nYou can view the report for today here: {attachment_link}"
    msg = MIMEText(email_body)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = ", ".join(recipient_emails)

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, recipient_emails, msg.as_string())
        server.quit()
        print("Email sent successfully")
    except Exception as e:
        print("Error sending email:", str(e))

def send_email(subject, message, recipient_email):
    sender_email = "davidrockecr7@gmail.com"  # Replace with your sender email
    sender_password = "bplrjzncurivkddk"  # Replace with your generated app password

    msg = MIMEText(message)
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = recipient_email

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, recipient_email, msg.as_string())
        server.quit()
        print("Email sent successfully")
    except Exception as e:
        print("Error sending email:", str(e))

def run_csharp_program(retries):
    for retry in range(retries):
        try:
            # Full path to the updated C# executable
            csharp_executable = r"C:\Users\ROSHAN DAVID\OneDrive\Desktop\Docs\FINAL-OUTPUT-ALL-VAHAN\WEBSCRAP-PROJ\PublishOutput\WEBSCRAP-PROJ.exe"

            # Run the C# program using subprocess
            subprocess.run([csharp_executable])
            print("C# program executed successfully.")
            return  # Exit the loop upon successful execution

        except subprocess.CalledProcessError as e:
            print("Error running C# program:", e)
            if retry < retries - 1:
                print(f"Retrying ({retry + 1}/{retries})...")
            else:
                send_email("Data Movement Failed", "Error occurred while running C# program.", "rdcr77777@gmail.com")
                print("Maximum retries reached. Exiting.")
                return  # Exit the loop after maximum retries

def run_python_script(script_name):
    try:
        subprocess.run(["python", script_name], check=True)
        print(f"Python script {script_name} completed.")
    except subprocess.CalledProcessError as e:
        print(f"Error occurred in {script_name}:", e)
        send_email("Data Movement Failed", f"Error occurred while running {script_name}.", "rdcr77777@gmail.com")
        raise SystemExit(1)  # Exit upon error


def run_scripts():
    print("Next run scheduled at:")
    next_run_time = time.time() + NEXT_SCHEDULE * 60
    while time.time() < next_run_time:
        seconds_remaining = int(next_run_time - time.time())
        print(f"Countdown: {seconds_remaining} seconds", end="\r")
        time.sleep(1)
    print("Running scripts...")
    
    try:
        run_csharp_program(MAX_RETRIES)
        run_python_script("csvtofl.py")
        run_python_script("filenamechange.py")
        run_python_script("validation.py")
        run_python_script("removefiles-update-4coloumns.py")
        run_python_script("excel-db.py")

        # Include the link to the Power BI report in the success email
        power_bi_link = "https://app.powerbi.com/links/zQeCa52rJX?ctid=3f89fba5-bf79-48c2-bfda-15fdca233ec6&pbi_source=linkShare"
        send_email_with_attachment("Data Movement Success", "All scripts executed successfully.", ["abuthaheer.u@sundaramfinance.in", "thanganila.m@sundaramfinance.in", "vyas.v@sundaramfinance.in", "arunpalaniappan@sundaramfinance.in", "rdcr7777@gmail.com"], power_bi_link)
    except SystemExit:
        pass  # Exit gracefully if an error occurred in the scripts

if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    run_scripts()

    schedule.every(NEXT_SCHEDULE).minutes.do(run_scripts)

    while True:
        schedule.run_pending()
        time.sleep(1)
