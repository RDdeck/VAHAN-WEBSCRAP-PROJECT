﻿// See https://aka.ms/new-console-template for more informatio


using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using Coypu;
using OpenQA.Selenium.Firefox;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;
using OpenQA.Selenium.Firefox;
using Microsoft.VisualBasic.FileIO;
using Coypu.Drivers;
using Microsoft.Office.Interop.Excel;
using OfficeOpenXml;
using System.ComponentModel;

class Wb
{
    static void Main(String[] args)
    {
        int maxRetries = 3;
        int retryCount = 0;
        bool interactedSuccessfully = false;
        int iSize =0;
        int iSize2 =0;
        int count2=5;
        
        String  statename;

        ChromeOptions c = new ChromeOptions();
        c.AddArguments("headless");
       
        c.AddArgument("log-level=3");


        //ChromeDriver driver = new ChromeDriver(c);
        /*var SessionConfiguration = new SessionConfiguration
        {
            Browser = Browser.Chrome,
            Timeout = TimeSpan.FromSeconds(10),

        };*/

        WebDriver driver = new ChromeDriver();
        //WebDriver driver = new FirefoxDriver();

        driver.Navigate().GoToUrl("https://vahan.parivahan.gov.in/vahan4dashboard/vahan/view/reportview.xhtml");
        driver.Manage().Window.Maximize();

        

        string fileName = @"C:\Users\ROSHAN DAVID\OneDrive\Desktop\Docs\FINAL-OUTPUT-ALL-VAHAN\WEBSCRAP-PROJ\textfiles\VahanDetails.txt";
        string filePath = @"C:\Users\ROSHAN DAVID\OneDrive\Desktop\Docs\FINAL-OUTPUT-ALL-VAHAN\WEBSCRAP-PROJ\textfiles\State.txt";
        string allState = @"C:\Users\ROSHAN DAVID\OneDrive\Desktop\Docs\FINAL-OUTPUT-ALL-VAHAN\WEBSCRAP-PROJ\textfiles\No_of_states.txt";

        
        

        List<String> dropId = new List<String>();
        List<String> buttonId = new List<String>();

        try
        {
            // Find all select (dropdown) elements on the page
            IReadOnlyCollection<IWebElement> dropdownElements = driver.FindElements(By.TagName("select"));

            // Find all button elements on the page
            IReadOnlyCollection<IWebElement> buttonElements = driver.FindElements(By.TagName("button"));

            // Extract and print the IDs of dropdowns

            foreach (IWebElement dropdownElement in dropdownElements)
            {

                while (retryCount < maxRetries)
                {

                    try
                    {
                        string elementId = dropdownElement.GetAttribute("id");
                        if (!string.IsNullOrEmpty(elementId))
                        {

                            Console.WriteLine("Dropdown ID: " + elementId);

                            dropId.Add(elementId);
                        }

                        interactedSuccessfully = true;
                        retryCount = 0;
                        break;
                    }
                    catch (StaleElementReferenceException)
                    {
                        dropdownElements = driver.FindElements(By.TagName("select"));
                        retryCount++;
                    }
                }


            }

            // Extract and print the IDs of buttons
            int indexToAccess = 1; // Replace with the index you want to access

            if (indexToAccess >= 0 && indexToAccess < buttonElements.Count)
            {

                IWebElement elementAtIndex = buttonElements.ElementAt(indexToAccess);

                while (retryCount < maxRetries)
                {
                    try
                    {

                        buttonElements = driver.FindElements(By.TagName("button"));

                        string elementId = elementAtIndex.GetAttribute("id");

                        Console.WriteLine("Button ID: " + elementId);
                        buttonId.Add(elementId);


                        interactedSuccessfully = true;
                        retryCount = 0;
                        break;
                    }
                    catch (StaleElementReferenceException)
                    {
                        retryCount++;
                    }
                }

            }

        }
        catch
        {

        }
           
     

    string[] lines = File.ReadAllLines(filePath);
        StreamReader sr=new StreamReader(allState);


        statename = sr.ReadLine();
        while (statename != null)
        {
            Console.WriteLine(statename);
            //Read the next line
            statename = sr.ReadLine();
        }
        sr.Close();
        int countline = lines.Count();
      
        Console.WriteLine("Count of Inclusion States: "+ countline);
        Console.WriteLine(dropId[1] + " " + buttonId[0]);

        Console.WriteLine("---------------------------------------------------------------");

        // Check if file already exists. If yes, delete it.     
        if (File.Exists(fileName))
        {
            File.Delete(fileName);
        }

        FileStream f = new FileStream(fileName,FileMode.Create);
        StreamWriter s = new StreamWriter(f);

        Thread.Sleep(1000);


   

        //  performAction(driver);

        IWebElement webele = driver.FindElement(By.Id("yaxisVar_input"));
        ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", webele); Thread.Sleep(3000);
        SelectElement drop2 = new SelectElement(webele);
        drop2.SelectByValue("Maker");
        string selectop = drop2.SelectedOption.Text;
        Console.WriteLine("Vehicle Class: " + selectop);
        Console.WriteLine(retryCount);

        while (retryCount < maxRetries)
        {
            try
            {
                string xid = dropId[4];
                IWebElement opt = driver.FindElement(By.Id(xid));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);",opt); Thread.Sleep(3000);
                SelectElement drop5 = new SelectElement(opt);
                drop5.SelectByValue("Vehicle Category");
                string opt2 = drop5.SelectedOption.Text;
                Console.WriteLine("Selected Option: " + opt2);

                interactedSuccessfully = true;
                retryCount = 0;
                break; // Exit the loop on successful interaction
            }
            catch (StaleElementReferenceException)
            {
                IWebElement opt = driver.FindElement(By.Id("xaxisVar_input"));
                //SelectElement drop5 = new SelectElement(opt);
                retryCount++;
            }

        }

        while (retryCount < maxRetries)
        {
            try
            {

                IWebElement cal = driver.FindElement(By.Id("selectedYearType_input"));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", cal); Thread.Sleep(3000);
                SelectElement drop3 = new SelectElement(cal);
                drop3.SelectByValue("F");
                string selectfin = drop3.SelectedOption.Text;
                Console.WriteLine("Year Type: " + selectfin);

                interactedSuccessfully = true;
                retryCount = 0;
                break; // Exit the loop on successful interaction
            }
            catch (StaleElementReferenceException)
            {
                IWebElement cal = driver.FindElement(By.Id("selectedYearType_input"));
                //SelectElement drop5 = new SelectElement(opt);
                retryCount++;
            }

        }

        IWebElement yearval = driver.FindElement(By.Id("selectedYear_input"));
       ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", yearval); Thread.Sleep(2000);

        while (retryCount < maxRetries)
        {
            try
            {
                SelectElement drop4 = new SelectElement(yearval);
                drop4.SelectByText("2023-2024");
                interactedSuccessfully = true;
                retryCount = 0;
                break;

            }
            catch (StaleElementReferenceException)
            {
                yearval = driver.FindElement(By.Id("selectedYear_input"));
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", yearval); Thread.Sleep(3000);
                SelectElement drop4 = new SelectElement(yearval);
                drop4.SelectByText("2023-2024");
                string selectyear = drop4.SelectedOption.Text;
                Console.WriteLine("Year: " + selectyear);
            }


        }

       
        Console.WriteLine("-----------------------------------------------------");
        // String sValue1 = elementCount[1].Text;
        // Console.WriteLine(sValue1);
        int C = 0;
            // foreach (IWebElement option in options)
            for (int j = 0; j < countline; j++)
            {
            String stateid = dropId[1];
            IWebElement dropdownElement = driver.FindElement(By.Id(stateid));

            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", dropdownElement); Thread.Sleep(1000);
            // WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            SelectElement dropdown = new SelectElement(dropdownElement);
            dropdown.SelectByValue(lines[j]);
            string selectedOptionText = dropdown.SelectedOption.Text;
            Console.WriteLine("Selected State: " + selectedOptionText);

            IWebElement RTO = driver.FindElement(By.Id(dropId[2]));
            SelectElement select = new SelectElement(RTO);
            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);",RTO); Thread.Sleep(1000);

            while (retryCount < maxRetries)
            {
                try
                {
                    IList<IWebElement> options = RTO.FindElements(By.TagName("option"));
                     iSize = options.Count;
                     iSize2 = iSize - 60;
                     
                   
                    interactedSuccessfully = true;
                    retryCount = 0;
                    break; // Exit the loop on successful interaction
                }
                catch(StaleElementReferenceException)
                {
                     RTO = driver.FindElement(By.Id("selectedRto_input"));
                     select = new SelectElement(RTO);
                   // IList<IWebElement> options = RTO.FindElements(By.TagName("option"));
                    retryCount++;
                }

            }


            Console.WriteLine(iSize);
            

            /*  int iSize = options.Count;
              int iSize2 = iSize - 140;
              Console.WriteLine(iSize);*/




            for (int i = 0; i < count2; i++)
            {
                
                try
                {

                    RTO = driver.FindElement(By.Id("selectedRto_input"));
                    select = new SelectElement(RTO);


                    // select.SelectByText(option.Text);
                    ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", RTO); Thread.Sleep(2000);

                    select.SelectByIndex(i);
                    // IWebElement selectedOption = select.SelectedOption;

                    // option.Click();



                    // Console.WriteLine("Selected option: " + selectedOption.Text);


                    Thread.Sleep(1000);
                    // get refresh id
                    String btnid = buttonId[0];
                    IWebElement r = driver.FindElement(By.Id(btnid));
                    r.Click();
                    Thread.Sleep(3000);
                    // elementCount.ElementAt(i).Click();
                    // Thread.Sleep(2000);

                    IWebElement exlName = driver.FindElement(By.XPath("//*[@id=\"groupingTable\"]/div[1]/span"));
                    s.WriteLine(exlName.Text);
                    Console.WriteLine(exlName.Text);

                    IWebElement exl = driver.FindElement(By.Id("groupingTable:xls"));
                    /* string currentDownloadAttr = exl.GetAttribute("onclick");
                     string newFileName = exlName.Text; // Change to the desired file name*/
                    ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", exl);
                    // exl.Click();
                    Thread.Sleep(3000);



                }


                catch (StaleElementReferenceException e)
                {
                    //performAction(driver);

                }


            }

        }



        s.Close();
        f.Close();

       




        Console.Write("ENd");

    }

   

}
