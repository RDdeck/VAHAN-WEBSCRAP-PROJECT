import os
import shutil
from datetime import datetime, date
from openpyxl import load_workbook

source_directory = r"C:\Users\ROSHAN DAVID\Downloads"
destination_directory = r'C:\Users\ROSHAN DAVID\OneDrive\Desktop\vahan-details'

# Get today's date
today = date.today()

# List all files in the source directory
excel_files = [file for file in os.listdir(source_directory) if file.endswith('.xlsx') or file.endswith('.xls')]

# Counter to keep track of the number of files moved
files_moved = 0

# Delete all files in the destination directory and count them
removed_files = 0
for existing_file in os.listdir(destination_directory):
    existing_file_path = os.path.join(destination_directory, existing_file)
    if os.path.isfile(existing_file_path):
        os.remove(existing_file_path)
        removed_files += 1

print(f"Removed {removed_files} files.")

for excel_file in excel_files:
    file_path = os.path.join(source_directory, excel_file)
    file_creation_date = datetime.fromtimestamp(os.path.getctime(file_path)).date()

    # Check if the file was created today
    if file_creation_date == today:
        destination_path = os.path.join(destination_directory, excel_file)

        # Move the file to the destination folder
        shutil.move(file_path, destination_path)
        files_moved += 1

        # Update the Excel file with downloaded time information
        try:
            workbook = load_workbook(destination_path)
            sheet = workbook.active

            # Add a column header
            sheet.cell(row=1, column=sheet.max_column + 1, value="Downloaded Time")

            # Fetch date modified and insert into the column for each row
            for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row):
                file_modified_time = datetime.fromtimestamp(os.path.getmtime(destination_path)).strftime('%Y-%m-%d %H:%M:%S')
                row[sheet.max_column - 1].value = file_modified_time

            # Save the changes
            workbook.save(destination_path)
            print(f"Downloaded time added to {excel_file}.")
        except Exception as e:
            print(f"An error occurred while updating {excel_file}: {e}")

if files_moved > 0:
    print(f"Moved {files_moved} Excel files to {destination_directory}.")
else:
    print("No Excel files downloaded today.")
