import os
import openpyxl

# Define the folder path containing the Excel files
folder_path = r"C:\Users\ROSHAN DAVID\OneDrive\Desktop\vahan-details"

# List all files in the folder
file_list = os.listdir(folder_path)

# Iterate through Excel files and change their names
for filename in file_list:
    if filename.lower().endswith('.xls') or filename.lower().endswith('.xlsx'):
        excel_file_path = os.path.join(folder_path, filename)
        
        # Open the Excel file using openpyxl
        workbook = openpyxl.load_workbook(excel_file_path)
        first_sheet = workbook.active
        
        # Get the value from the first cell (A1)
        new_name = first_sheet.cell(row=1, column=1).value
        new_name = new_name.replace("/", "_")  # Handle special characters
        
        # Construct the new path with the renamed filename
        new_file_path = os.path.join(folder_path, new_name + os.path.splitext(filename)[1])
        
        # Rename the file
        os.rename(excel_file_path, new_file_path)
        print(f"Renamed '{filename}' to '{new_name}'")
        
        print(" ")
        
        print("********************************************************************************************************")
