import os
import re
import pandas as pd

# Define regex patterns for extraction
state_pattern = r', (.*?) \('
branch_pattern = r'of (.*?) - |of (.*?) \('
regno_pattern = r'- (\w+) ,'
year_pattern = r'\((\d{4}-\d{4})\)'

# Input and output directories
input_directory = r"C:\Users\ROSHAN DAVID\OneDrive\Desktop\vahan-details"
output_directory = r"C:\Users\ROSHAN DAVID\OneDrive\Desktop\vahan-details\updated_excel"

# Remove existing files from the output directory
removed_files = []
for filename in os.listdir(output_directory):
    if filename.endswith(".xlsx"):
        removed_file = os.path.join(output_directory, filename)
        os.remove(removed_file)
        removed_files.append(filename)

if removed_files:
    print(f"Removed {len(removed_files)} files from the output directory.")

# Process Excel files in the input directory
for filename in os.listdir(input_directory):
    if filename.endswith(".xlsx"):
        # Load Excel file into DataFrame
        df = pd.read_excel(os.path.join(input_directory, filename))
        
        # Extract information from the file name
        state_match = re.search(state_pattern, filename)
        branch_match = re.search(branch_pattern, filename)
        regno_match = re.search(regno_pattern, filename)
        year_match = re.search(year_pattern, filename)

        if state_match:
            state = state_match.group(1).strip()
        else:
            state_alt_pattern = r'of (.*?) \('
            state_alt_match = re.search(state_alt_pattern, filename)
            if state_alt_match:
                state = state_alt_match.group(1).strip()
            else:
                state = "N/A"

        if branch_match and branch_match.group(1):
            branch = branch_match.group(1).strip()
        else:
            branch = "N/A"

        regno = regno_match.group(1).strip() if regno_match else "N/A"
        year = year_match.group(1).strip() if year_match else "N/A"

        if branch == "N/A" and regno == "N/A":
            branch = "ALL"
            regno = "ALL"
        
        # Add new columns with extracted information
        df["State"] = state
        df["Branch"] = branch
        df["RegNo"] = regno
        df["Year"] = year
        
        # Save the updated DataFrame back to Excel
        updated_filename = os.path.join(output_directory, filename)
        df.to_excel(updated_filename, index=False)

        print(f"Processed and updated: {filename}")
